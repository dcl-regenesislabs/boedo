import type { Entity } from '@dcl/sdk/ecs'
import type { ColorHex } from '../../../src/scripts/runtime/authoring'
import { setUiTheme } from '../../../src/scripts/runtime/uiTheme'

export class UiTheme {
  constructor(
    public src: string,
    public entity: Entity,
    public accentColor: ColorHex = '#FF2D55',
    public appearance: 'Dark' | 'Light' = 'Dark'
  ) {}

  start(): void {
    setUiTheme(this.entity, this.accentColor, this.appearance)
  }
}
