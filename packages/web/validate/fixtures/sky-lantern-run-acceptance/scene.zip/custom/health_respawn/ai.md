---
prefab: health-respawn
claims-state: game.state.health
claims-messages: respawn
---

# Health & Respawn — AI guide

Hit points the server owns, and a respawn point players come back to.

The project copy is normally custom/health_respawn/ — check what is on disk, a
second copy is custom/health_respawn_2/.

## When to use

Any scene where players can die: a fall, a hazard, a fight. Place ONE anywhere;
it is invisible. A second copy is a no-op (the first one's params win).

Do NOT write your own health map, death check or teleport-home code — this prefab
owns all three, and health a client can edit is health nobody can trust.

## API

    import { damage, healthOf } from '../../custom/health_respawn/scripts/health'

- `damage(player, amount)` — WHICH SIDE: the SERVER, inside the `if (isServer())`
  branch, from a `game.onRequest`, `game.onEnterArea`, `game.every` or
  `game.onRoundStart` handler. Takes the player to a minimum of 0; at 0 this
  prefab refills them and respawns them after respawnDelay, checked every half
  second. A player who is not in the scene is ignored.
- `healthOf(player)` — reads hit points on either side, the client included.
- `heal(player, amount)` and `kill(player)` — SERVER helpers from the same health.ts.
  Healing caps at maxHealth and cannot revive a dead player. kill forces health to zero.
- `lifeOf(player)` — reads life number, death count, dead status, respawnAt and
  protectedUntil, or null before the player joins. Times use game.now().
- `game.state.health` — the whole `{ wallet: points }` map, readable on every
  client and by late joiners. Read it to draw bars or count who is alive; never
  write it.

Params of the prefab's script — set them in the placePrefab request:

- `respawnAt`: the entity players come back to. Pick a pad or marker that sits at
  the scene root — the position is read straight off its Transform. Until it is
  picked, nothing respawns and the console says so.
- `maxHealth`: hit points a player starts every life with (default 100). Also the
  refill at a new round.
- `dieBelowHeight`: players below this height die (default 0 = off). This is the
  death plane for a climbing or platforming scene; set it under the lowest floor
  a player is allowed to stand on.
- `respawnDelay`: seconds to remain dead before returning (default 0).
- `protectionSeconds`: damage/fall protection after returning (default 1).

Checkpoint destinations and an explicit restart move use the shared
`src/scripts/runtime/respawn.ts` module; read its header. Health & Respawn must
be placed to receive the move. Each player's destination overrides respawnAt;
leaving clears it. The course owns resetting destinations at a new round or
personal restart; Run Progress does both before requesting the move.
The owner also publishes game.state.healthLife and game.state.healthMax for HUDs.

## Hazards

A hurting area is a Trigger Area plus one handler in the server branch — this
prefab deliberately has no area list, because damage belongs to it and detection
belongs to the area. `game.onEnterArea` is a server verb:

    start(): void {
      if (isServer()) {
        game.onEnterArea('Moat', (player) => damage(player, 100))
        return
      }
    }

## Do / Don't

- DON'T call `damage` on the client. Only the server changes synced state, so the
  call does nothing there.
- DON'T teleport a dead player yourself. The server broadcasts `respawn` to that
  one player and their own client moves them; a `movePlayerTo` in your code moves
  the wrong avatar or none.
- DON'T handle `respawn` yourself with `game.onBroadcast('respawn', …)`. This
  prefab already listens on it, on the client side.
- DO reset scores in `game.onRoundStart` if you also want a fresh scoreboard —
  this prefab only refills health.

## Example

"Kill anyone who falls off the tower and send them back to the base": place Health
& Respawn, pick the BaseSpawn pad as `respawnAt`, and set `dieBelowHeight` to the
height just under the tower's first floor. No script at all.
