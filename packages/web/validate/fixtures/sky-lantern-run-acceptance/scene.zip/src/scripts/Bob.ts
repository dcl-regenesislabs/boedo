import { EasingFunction, Entity, Transform, Tween, TweenLoop, TweenSequence } from '@dcl/sdk/ecs'
import { Vector3 } from '@dcl/sdk/math'
import { isServer } from '@dcl/sdk/network'

/** Decorative gentle bobbing (orbs, sky lanterns). Purely visual, so a local tween is fine. */
export class Bob {
  constructor(
    public src: string,
    public entity: Entity,
    /** Rise in metres */
    public height: number = 0.25,
    /** Seconds for one rise */
    public seconds: number = 1.6
  ) {}

  start(): void {
    if (isServer()) return
    const t = Transform.getOrNull(this.entity)
    if (t === null) return
    const from = Vector3.clone(t.position)
    const to = Vector3.add(from, Vector3.create(0, this.height, 0))
    Tween.setMove(this.entity, from, to, Math.max(0.1, this.seconds) * 1000, EasingFunction.EF_EASESINE)
    TweenSequence.createOrReplace(this.entity, { sequence: [], loop: TweenLoop.TL_YOYO })
  }
}
