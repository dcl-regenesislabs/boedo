import { engine, Entity, SkyboxTime } from '@dcl/sdk/ecs'
import { isServer } from '@dcl/sdk/network'

/** Pins the scene sky to a fixed time of day (default: golden sunset). */
export class SunsetSky {
  constructor(
    public src: string,
    public entity: Entity,
    /** Hour of day, 0-24. 18.3 is a warm sunset. */
    public hour: number = 18.3
  ) {}

  start(): void {
    if (isServer()) return
    const seconds = Math.round(Math.min(24, Math.max(0, this.hour)) * 3600)
    SkyboxTime.createOrReplace(engine.RootEntity, { fixedTime: seconds })
  }
}
